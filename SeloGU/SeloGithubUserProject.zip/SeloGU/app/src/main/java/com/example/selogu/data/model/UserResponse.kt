package com.example.selogu.data.model

data class UserResponse(
    val items : ArrayList<User>
)
